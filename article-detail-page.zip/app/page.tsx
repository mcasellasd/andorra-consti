import { ArticleDetailPage } from "@/components/article-detail-page"

export default function Page() {
  return <ArticleDetailPage />
}
